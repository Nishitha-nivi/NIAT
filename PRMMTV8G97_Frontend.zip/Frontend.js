let timer;
let timeLeft = 0;
let running = false;

function updateDisplay() {
    let minutes = Math.floor(timeLeft / 60);
    let seconds = timeLeft % 60;
    document.getElementById('display').textContent =
        String(minutes).padStart(2, '0') + ':' + String(seconds).padStart(2, '0');
}

function startTimer() {
    if (!running && timeLeft > 0) {
        running = true;
        timer = setInterval(() => {
            if (timeLeft > 0) {
                timeLeft--;
                updateDisplay();
            } else {
                clearInterval(timer);
                running = false;
            }
        }, 1000);
    }
}

function pauseTimer() {
    clearInterval(timer);
    running = false;
}

function resetTimer() {
    clearInterval(timer);
    timeLeft = 0;
    running = false;
    updateDisplay();
}

function stopTimer() {
    clearInterval(timer);
    running = false;
    updateDisplay();
}

function setTimer(minutes) {
    clearInterval(timer);
    timeLeft = minutes * 60;
    running = false;
    updateDisplay();
}

updateDisplay();